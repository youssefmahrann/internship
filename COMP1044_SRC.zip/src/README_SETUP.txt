Setup in XAMPP:
1. Import COMP1044_database.sql into phpMyAdmin.
2. Put the src folder in htdocs.
3. Open src/login.php.
Admin login: admin@university.edu / Admin@1234
Assessor login: ahmad.razali@university.edu / Pass@1234
