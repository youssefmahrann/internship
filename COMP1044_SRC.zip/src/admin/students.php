<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_admin();

$db = get_db();

// ---- Handle POST actions ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $num  = trim($_POST['student_number'] ?? '');
        $name = trim($_POST['full_name']      ?? '');
        $email= trim($_POST['email']          ?? '');
        $prog = (int)($_POST['programme_id']  ?? 0);

        $errors = [];
        if (!$num)  $errors[] = 'Student number is required.';
        if (!$name) $errors[] = 'Full name is required.';
        if (!$prog) $errors[] = 'Programme is required.';
        if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email address.';

        if (empty($errors)) {
            if ($action === 'add') {
                // Check duplicate student_number
                $chk = $db->prepare("SELECT student_id FROM students WHERE student_number=?");
                $chk->bind_param('s', $num); $chk->execute();
                if ($chk->get_result()->num_rows > 0) {
                    set_flash('danger', 'Student number already exists.');
                } else {
                    $ins = $db->prepare("INSERT INTO students (student_number,full_name,email,programme_id) VALUES (?,?,?,?)");
                    $ins->bind_param('sssi', $num, $name, $email, $prog);
                    $ins->execute();
                    set_flash('success', 'Student added successfully.');
                }
            } else {
                $id  = (int)($_POST['student_id'] ?? 0);
                $upd = $db->prepare("UPDATE students SET student_number=?,full_name=?,email=?,programme_id=? WHERE student_id=?");
                $upd->bind_param('sssii', $num, $name, $email, $prog, $id);
                $upd->execute();
                set_flash('success', 'Student updated successfully.');
            }
        } else {
            set_flash('danger', implode(' ', $errors));
        }
    }
    header('Location: students.php');
    exit();
}

// ---- Handle GET delete ----
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    // Check if student has internships
    $chk = $db->prepare("SELECT COUNT(*) c FROM internships WHERE student_id=?");
    $chk->bind_param('i', $id); $chk->execute();
    $cnt = $chk->get_result()->fetch_assoc()['c'];
    if ($cnt > 0) {
        set_flash('danger', 'Cannot delete student with existing internship records.');
    } else {
        $del = $db->prepare("DELETE FROM students WHERE student_id=?");
        $del->bind_param('i', $id); $del->execute();
        set_flash('success', 'Student deleted.');
    }
    header('Location: students.php'); exit();
}

// ---- Fetch data ----
$search = trim($_GET['q'] ?? '');
$sql = "SELECT s.*, p.programme_name
        FROM students s
        JOIN programmes p ON p.programme_id = s.programme_id";
if ($search) {
    $like = '%' . $db->real_escape_string($search) . '%';
    $sql .= " WHERE s.student_number LIKE '$like' OR s.full_name LIKE '$like'";
}
$sql .= " ORDER BY s.student_number";
$students = $db->query($sql)->fetch_all(MYSQLI_ASSOC);

$programmes = $db->query("SELECT * FROM programmes ORDER BY programme_name")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Students';
$active_nav = 'students';
$base = '../';
require_once '../includes/header.php';
?>

<div class="section-header">
  <h2 class="section-title">Students</h2>
  <button class="btn btn-primary" onclick="openModal('modal-add')">+ Add Student</button>
</div>

<!-- Search -->
<div class="card" style="margin-bottom:20px;">
  <div class="card-body" style="padding:14px 18px;">
    <form method="get" action="students.php" style="display:flex;gap:10px;">
      <input type="text" name="q" class="search-input" placeholder="Search by name or student number…"
             value="<?= esc($search) ?>">
      <button type="submit" class="btn btn-primary">Search</button>
      <?php if ($search): ?>
        <a href="students.php" class="btn btn-secondary">Clear</a>
      <?php endif; ?>
    </form>
  </div>
</div>

<!-- Table -->
<div class="card">
  <div class="card-body no-pad">
    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>Student No.</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Programme</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($students)): ?>
          <tr><td colspan="5">
            <div class="empty-state">
              <div class="empty-state-icon">◌</div>
              <div class="empty-state-text">No students found.</div>
            </div>
          </td></tr>
          <?php else: foreach ($students as $s): ?>
          <tr>
            <td><strong><?= esc($s['student_number']) ?></strong></td>
            <td><?= esc($s['full_name']) ?></td>
            <td><?= esc($s['email'] ?? '—') ?></td>
            <td><?= esc($s['programme_name']) ?></td>
            <td>
              <div style="display:flex;gap:6px;">
                <button class="btn btn-secondary btn-sm"
                  onclick="editStudent(<?= htmlspecialchars(json_encode($s), ENT_QUOTES) ?>)">Edit</button>
                <button class="btn btn-danger btn-sm"
                  onclick="confirmDelete('students.php?delete=<?= $s['student_id'] ?>','<?= esc($s['full_name']) ?>')">Delete</button>
              </div>
            </td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="modal-add">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Add New Student</span>
      <button class="modal-close" onclick="closeModal('modal-add')">×</button>
    </div>
    <form method="post" action="students.php" data-validate>
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">Student Number <span class="req">*</span></label>
            <input type="text" name="student_number" class="form-control" required placeholder="e.g. 21CS001">
            <span class="form-error"></span>
          </div>
          <div class="form-group">
            <label class="form-label">Full Name <span class="req">*</span></label>
            <input type="text" name="full_name" class="form-control" required placeholder="Full name">
            <span class="form-error"></span>
          </div>
          <div class="form-group">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" placeholder="student@email.com">
          </div>
          <div class="form-group">
            <label class="form-label">Programme <span class="req">*</span></label>
            <select name="programme_id" class="form-control" required>
              <option value="">Select programme…</option>
              <?php foreach ($programmes as $p): ?>
                <option value="<?= $p['programme_id'] ?>"><?= esc($p['programme_name']) ?></option>
              <?php endforeach; ?>
            </select>
            <span class="form-error"></span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modal-add')">Cancel</button>
        <button type="submit" class="btn btn-primary">Add Student</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="modal-edit">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Edit Student</span>
      <button class="modal-close" onclick="closeModal('modal-edit')">×</button>
    </div>
    <form method="post" action="students.php" data-validate>
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="student_id" id="edit-student-id">
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">Student Number <span class="req">*</span></label>
            <input type="text" name="student_number" id="edit-student-number" class="form-control" required>
            <span class="form-error"></span>
          </div>
          <div class="form-group">
            <label class="form-label">Full Name <span class="req">*</span></label>
            <input type="text" name="full_name" id="edit-full-name" class="form-control" required>
            <span class="form-error"></span>
          </div>
          <div class="form-group">
            <label class="form-label">Email</label>
            <input type="email" name="email" id="edit-email" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">Programme <span class="req">*</span></label>
            <select name="programme_id" id="edit-programme" class="form-control" required>
              <option value="">Select programme…</option>
              <?php foreach ($programmes as $p): ?>
                <option value="<?= $p['programme_id'] ?>"><?= esc($p['programme_name']) ?></option>
              <?php endforeach; ?>
            </select>
            <span class="form-error"></span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modal-edit')">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script>
function editStudent(s) {
  document.getElementById('edit-student-id').value     = s.student_id;
  document.getElementById('edit-student-number').value = s.student_number;
  document.getElementById('edit-full-name').value      = s.full_name;
  document.getElementById('edit-email').value          = s.email ?? '';
  document.getElementById('edit-programme').value      = s.programme_id;
  openModal('modal-edit');
}
</script>
<?php require_once '../includes/footer.php'; ?>
