<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_admin();

$db = get_db();

// Statistics
$stats = [];
$stats['students']     = $db->query("SELECT COUNT(*) c FROM students")->fetch_assoc()['c'];
$stats['internships']  = $db->query("SELECT COUNT(*) c FROM internships")->fetch_assoc()['c'];
$stats['assessors']    = $db->query("SELECT COUNT(*) c FROM users WHERE role='assessor'")->fetch_assoc()['c'];
$stats['completed']    = $db->query("SELECT COUNT(*) c FROM internships WHERE status='completed'")->fetch_assoc()['c'];
$stats['assessed']     = $db->query("SELECT COUNT(*) c FROM assessments WHERE submitted_at IS NOT NULL")->fetch_assoc()['c'];
$stats['ongoing']      = $db->query("SELECT COUNT(*) c FROM internships WHERE status='ongoing'")->fetch_assoc()['c'];

// Recent internships
$recent = $db->query("
    SELECT i.internship_id, s.student_number, s.full_name AS student_name,
           c.company_name, u.full_name AS assessor_name, i.status,
           vat.total_score
    FROM internships i
    JOIN students  s ON s.student_id  = i.student_id
    JOIN companies c ON c.company_id  = i.company_id
    JOIN users     u ON u.user_id     = i.assessor_id
    LEFT JOIN v_assessment_totals vat ON vat.internship_id = i.internship_id
    ORDER BY i.created_at DESC LIMIT 8
")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Dashboard';
$active_nav = 'dashboard';
$base = '../';
require_once '../includes/header.php';
?>

<div class="stats-grid">
  <div class="stat-card stat-accent">
    <div class="stat-label">Total Students</div>
    <div class="stat-value"><?= $stats['students'] ?></div>
    <div class="stat-sub">Registered in system</div>
  </div>
  <div class="stat-card stat-info">
    <div class="stat-label">Internships</div>
    <div class="stat-value"><?= $stats['internships'] ?></div>
    <div class="stat-sub"><?= $stats['ongoing'] ?> ongoing</div>
  </div>
  <div class="stat-card stat-success">
    <div class="stat-label">Completed</div>
    <div class="stat-value"><?= $stats['completed'] ?></div>
    <div class="stat-sub"><?= $stats['assessed'] ?> assessed</div>
  </div>
  <div class="stat-card stat-warning">
    <div class="stat-label">Assessors</div>
    <div class="stat-value"><?= $stats['assessors'] ?></div>
    <div class="stat-sub">Active staff accounts</div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <span class="card-title">Recent Internships</span>
    <a href="internships.php" class="btn btn-secondary btn-sm">View All</a>
  </div>
  <div class="card-body no-pad">
    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Student</th>
            <th>Company</th>
            <th>Assessor</th>
            <th>Status</th>
            <th>Score</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($recent)): ?>
          <tr><td colspan="7">
            <div class="empty-state">
              <div class="empty-state-icon">◌</div>
              <div class="empty-state-text">No internships recorded yet.</div>
            </div>
          </td></tr>
          <?php else: foreach ($recent as $r): ?>
          <tr>
            <td><?= $r['internship_id'] ?></td>
            <td>
              <div style="font-weight:500"><?= esc($r['student_name']) ?></div>
              <div style="font-size:.78rem;color:var(--text-ter)"><?= esc($r['student_number']) ?></div>
            </td>
            <td><?= esc($r['company_name']) ?></td>
            <td><?= esc($r['assessor_name']) ?></td>
            <td>
              <?php
              $badges = ['completed'=>'badge-success','ongoing'=>'badge-info','withdrawn'=>'badge-danger'];
              $bc = $badges[$r['status']] ?? 'badge-neutral';
              ?>
              <span class="badge <?= $bc ?>"><?= ucfirst($r['status']) ?></span>
            </td>
            <td>
              <?php if ($r['total_score'] !== null): ?>
                <strong><?= number_format($r['total_score'],2) ?></strong>
              <?php else: ?>
                <span style="color:var(--text-ter)">—</span>
              <?php endif; ?>
            </td>
            <td>
              <a href="results.php?internship_id=<?= $r['internship_id'] ?>" class="btn btn-secondary btn-sm">View</a>
            </td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
