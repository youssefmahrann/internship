<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_admin();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

$db = get_db();

// ---- POST actions ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name    = trim($_POST['full_name'] ?? '');
        $email   = trim($_POST['email']     ?? '');
        $pw      = trim($_POST['password']  ?? '');
        $active  = isset($_POST['is_active']) ? 1 : 0;

        $errors = [];
        if (!$name)  $errors[] = 'Full name is required.';
        if (!$email) $errors[] = 'Email is required.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email.';
        if ($action === 'add' && !$pw) $errors[] = 'Password is required.';
        if ($pw && strlen($pw) < 6) $errors[] = 'Password must be at least 6 characters.';

        if (empty($errors)) {
            if ($action === 'add') {
                $chk = $db->prepare("SELECT user_id FROM users WHERE email=?");
                $chk->bind_param('s', $email); $chk->execute();
                if ($chk->get_result()->num_rows > 0) {
                    set_flash('danger', 'Email already exists.');
                } else {
                    $hash = password_hash($pw, PASSWORD_BCRYPT);
                    $ins  = $db->prepare("INSERT INTO users (full_name,email,password_hash,role,is_active) VALUES (?,?,?,'assessor',?)");
                    $ins->bind_param('sssi', $name, $email, $hash, $active);
                    $ins->execute();
                    set_flash('success', 'Assessor account created.');
                }
            } else {
                $id = (int)($_POST['user_id'] ?? 0);
                if ($pw) {
                    $hash = password_hash($pw, PASSWORD_BCRYPT);
                    $upd  = $db->prepare("UPDATE users SET full_name=?,email=?,password_hash=?,is_active=? WHERE user_id=? AND role='assessor'");
                    $upd->bind_param('sssii', $name, $email, $hash, $active, $id);
                } else {
                    $upd = $db->prepare("UPDATE users SET full_name=?,email=?,is_active=? WHERE user_id=? AND role='assessor'");
                    $upd->bind_param('ssii', $name, $email, $active, $id);
                }
                $upd->execute();
                set_flash('success', 'Assessor updated.');
            }
        } else {
            set_flash('danger', implode(' ', $errors));
        }
    }
    header('Location: assessors.php?refresh=' . time());
}

// Delete assessments directly linked to assessor
$getAssessments = $db->prepare("SELECT assessment_id FROM assessments WHERE assessor_id=?");
$getAssessments->bind_param('i', $id);
$getAssessments->execute();
$ares = $getAssessments->get_result();

while ($arow = $ares->fetch_assoc()) {
    $assessment_id = (int)$arow['assessment_id'];

    $delScores = $db->prepare("DELETE FROM assessment_scores WHERE assessment_id=?");
    $delScores->bind_param('i', $assessment_id);
    $delScores->execute();
}

$delAssessmentsByAssessor = $db->prepare("DELETE FROM assessments WHERE assessor_id=?");
$delAssessmentsByAssessor->bind_param('i', $id);
$delAssessmentsByAssessor->execute();

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];

    $db->begin_transaction();

    try {
        // Delete score rows linked to assessments for internships assigned to this assessor
        $q1 = $db->prepare("
            DELETE s
            FROM assessment_scores s
            INNER JOIN assessments a ON a.assessment_id = s.assessment_id
            INNER JOIN internships i ON i.internship_id = a.internship_id
            WHERE i.assessor_id = ?
        ");
        $q1->bind_param('i', $id);
        $q1->execute();

        // Delete assessments linked to internships assigned to this assessor
        $q2 = $db->prepare("
            DELETE a
            FROM assessments a
            INNER JOIN internships i ON i.internship_id = a.internship_id
            WHERE i.assessor_id = ?
        ");
        $q2->bind_param('i', $id);
        $q2->execute();

        // Delete internships assigned to this assessor
        $q3 = $db->prepare("DELETE FROM internships WHERE assessor_id = ?");
        $q3->bind_param('i', $id);
        $q3->execute();

        // Delete the assessor user row
        $q4 = $db->prepare("DELETE FROM users WHERE user_id = ? AND role = 'assessor'");
        $q4->bind_param('i', $id);
        $q4->execute();

        $db->commit();
        set_flash('success', 'Assessor and related records deleted.');
    } catch (Throwable $e) {
        $db->rollback();
        set_flash('danger', 'Delete failed: ' . $e->getMessage());
    }

    header('Location: assessors.php?refresh=' . time());
    exit();
}

// ---- Toggle active ----
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $db->query("UPDATE users SET is_active = 1 - is_active WHERE user_id = $id AND role='assessor'");
    set_flash('success', 'Account status updated.');
    header('Location: assessors.php?refresh=' . time());
}

$assessors = $db->query("
    SELECT u.*, COUNT(i.internship_id) AS intern_count
    FROM users u
    LEFT JOIN internships i ON i.assessor_id = u.user_id
    WHERE u.role = 'assessor'
    GROUP BY u.user_id
    ORDER BY u.full_name
")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Assessors';
$active_nav = 'assessors';
$base = '../';
require_once '../includes/header.php';
?>

<div class="section-header">
  <h2 class="section-title">Assessor Accounts</h2>
  <button class="btn btn-primary" onclick="openModal('modal-add')">+ Add Assessor</button>
</div>

<div class="card">
  <div class="card-body no-pad">
    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Internships</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($assessors)): ?>
          <tr><td colspan="5"><div class="empty-state"><div class="empty-state-icon">◌</div><div class="empty-state-text">No assessors found.</div></div></td></tr>
          <?php else: foreach ($assessors as $a): ?>
          <tr>
            <td>
              <div style="display:flex;align-items:center;gap:10px;">
                <div class="user-avatar" style="width:30px;height:30px;font-size:.78rem;"><?= strtoupper(substr($a['full_name'],0,1)) ?></div>
                <strong><?= esc($a['full_name']) ?></strong>
              </div>
            </td>
            <td><?= esc($a['email']) ?></td>
            <td><span class="badge badge-neutral"><?= $a['intern_count'] ?></span></td>
            <td>
              <span class="badge <?= $a['is_active'] ? 'badge-success' : 'badge-danger' ?>">
                <?= $a['is_active'] ? 'Active' : 'Inactive' ?>
              </span>
            </td>
            <td>
              <div style="display:flex;gap:6px;">
                <button class="btn btn-secondary btn-sm"
                  onclick="editAssessor(<?= htmlspecialchars(json_encode($a), ENT_QUOTES) ?>)">Edit</button>
                <a href="assessors.php?toggle=<?= $a['user_id'] ?>" class="btn btn-secondary btn-sm">
                  <?= $a['is_active'] ? 'Deactivate' : 'Activate' ?>
                </a>
                <button class="btn btn-danger btn-sm"
                  onclick="confirmDelete('assessors.php?delete=<?= $a['user_id'] ?>','<?= esc($a['full_name']) ?>')">Delete</button>
              </div>
            </td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="modal-add">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Add Assessor Account</span>
      <button class="modal-close" onclick="closeModal('modal-add')">×</button>
    </div>
    <form method="post" data-validate>
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-group form-full">
            <label class="form-label">Full Name <span class="req">*</span></label>
            <input type="text" name="full_name" class="form-control" required>
            <span class="form-error"></span>
          </div>
          <div class="form-group">
            <label class="form-label">Email <span class="req">*</span></label>
            <input type="email" name="email" class="form-control" required>
            <span class="form-error"></span>
          </div>
          <div class="form-group">
            <label class="form-label">Password <span class="req">*</span></label>
            <input type="password" name="password" id="password-input" class="form-control" required>
            <div style="margin-top:6px;">
              <div class="score-bar-wrap"><div class="score-bar" id="pwd-strength-bar" style="width:0"></div></div>
              <span id="pwd-strength-lbl" style="font-size:.75rem;color:var(--text-ter)"></span>
            </div>
            <span class="form-error"></span>
          </div>
          <div class="form-group" style="align-self:end;">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
              <input type="checkbox" name="is_active" checked> Active account
            </label>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modal-add')">Cancel</button>
        <button type="submit" class="btn btn-primary">Create Account</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="modal-edit">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Edit Assessor</span>
      <button class="modal-close" onclick="closeModal('modal-edit')">×</button>
    </div>
    <form method="post" data-validate>
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="user_id" id="edit-uid">
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-group form-full">
            <label class="form-label">Full Name <span class="req">*</span></label>
            <input type="text" name="full_name" id="edit-name" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">Email <span class="req">*</span></label>
            <input type="email" name="email" id="edit-email" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">New Password <small style="color:var(--text-ter)">(leave blank to keep)</small></label>
            <input type="password" name="password" class="form-control" placeholder="(unchanged)">
          </div>
          <div class="form-group" style="align-self:end;">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
              <input type="checkbox" name="is_active" id="edit-active"> Active account
            </label>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modal-edit')">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script>
function editAssessor(a) {
  document.getElementById('edit-uid').value   = a.user_id;
  document.getElementById('edit-name').value  = a.full_name;
  document.getElementById('edit-email').value = a.email;
  document.getElementById('edit-active').checked = a.is_active == 1;
  openModal('modal-edit');
}
</script>
<?php require_once '../includes/footer.php'; ?>
