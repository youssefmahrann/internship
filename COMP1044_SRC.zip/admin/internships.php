<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_admin();

$db = get_db();

// ---- POST ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action    = $_POST['action']      ?? '';
    $student   = (int)($_POST['student_id']  ?? 0);
    $company   = (int)($_POST['company_id']  ?? 0);
    $assessor  = (int)($_POST['assessor_id'] ?? 0);
    $start     = $_POST['start_date']  ?? '';
    $end       = $_POST['end_date']    ?? '';
    $year      = trim($_POST['academic_year'] ?? '');
    $status    = $_POST['status']      ?? 'ongoing';

    $errors = [];
    if (!$student)  $errors[] = 'Student is required.';
    if (!$company)  $errors[] = 'Company is required.';
    if (!$assessor) $errors[] = 'Assessor is required.';
    if (!$year)     $errors[] = 'Academic year is required.';

    if (empty($errors)) {
        if ($action === 'add') {
            $ins = $db->prepare("INSERT INTO internships (student_id,company_id,assessor_id,start_date,end_date,academic_year,status) VALUES (?,?,?,?,?,?,?)");
            $ins->bind_param('iiissss', $student, $company, $assessor, $start, $end, $year, $status);
            $ins->execute();
            set_flash('success', 'Internship record added.');
        } else {
            $id = (int)($_POST['internship_id'] ?? 0);
            $upd = $db->prepare("UPDATE internships SET student_id=?,company_id=?,assessor_id=?,start_date=?,end_date=?,academic_year=?,status=? WHERE internship_id=?");
            $upd->bind_param('iiissssi', $student, $company, $assessor, $start, $end, $year, $status, $id);
            $upd->execute();
            set_flash('success', 'Internship updated.');
        }
    } else {
        set_flash('danger', implode(' ', $errors));
    }
    header('Location: internships.php'); exit();
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $del = $db->prepare("DELETE FROM internships WHERE internship_id=?");
    $del->bind_param('i', $id); $del->execute();
    set_flash('success', 'Internship deleted.');
    header('Location: internships.php'); exit();
}

// ---- Fetch ----
$search = trim($_GET['q'] ?? '');
$sql = "
    SELECT i.*, s.full_name AS student_name, s.student_number,
           c.company_name, u.full_name AS assessor_name,
           vat.total_score
    FROM internships i
    JOIN students  s ON s.student_id  = i.student_id
    JOIN companies c ON c.company_id  = i.company_id
    JOIN users     u ON u.user_id     = i.assessor_id
    LEFT JOIN v_assessment_totals vat ON vat.internship_id = i.internship_id
";
if ($search) {
    $like = '%' . $db->real_escape_string($search) . '%';
    $sql .= " WHERE s.full_name LIKE '$like' OR s.student_number LIKE '$like' OR c.company_name LIKE '$like'";
}
$sql .= " ORDER BY i.internship_id DESC";
$internships = $db->query($sql)->fetch_all(MYSQLI_ASSOC);

$students  = $db->query("SELECT student_id,student_number,full_name FROM students ORDER BY full_name")->fetch_all(MYSQLI_ASSOC);
$companies = $db->query("SELECT * FROM companies ORDER BY company_name")->fetch_all(MYSQLI_ASSOC);
$assessors = $db->query("SELECT user_id,full_name FROM users WHERE role='assessor' AND is_active=1 ORDER BY full_name")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Internships';
$active_nav = 'internships';
$base = '../';
require_once '../includes/header.php';
?>

<div class="section-header">
  <h2 class="section-title">Internship Records</h2>
  <button class="btn btn-primary" onclick="openModal('modal-add')">+ Add Internship</button>
</div>

<div class="card" style="margin-bottom:20px;">
  <div class="card-body" style="padding:14px 18px;">
    <form method="get" style="display:flex;gap:10px;">
      <input type="text" name="q" class="search-input" placeholder="Search student, company…" value="<?= esc($search) ?>">
      <button type="submit" class="btn btn-primary">Search</button>
      <?php if ($search): ?><a href="internships.php" class="btn btn-secondary">Clear</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-body no-pad">
    <div class="table-wrapper">
      <table>
        <thead>
          <tr><th>#</th><th>Student</th><th>Company</th><th>Assessor</th><th>Year</th><th>Status</th><th>Score</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <?php if (empty($internships)): ?>
          <tr><td colspan="8"><div class="empty-state"><div class="empty-state-icon">◌</div><div class="empty-state-text">No internships found.</div></div></td></tr>
          <?php else: foreach ($internships as $i): ?>
          <tr>
            <td><?= $i['internship_id'] ?></td>
            <td>
              <div style="font-weight:500"><?= esc($i['student_name']) ?></div>
              <div style="font-size:.78rem;color:var(--text-ter)"><?= esc($i['student_number']) ?></div>
            </td>
            <td><?= esc($i['company_name']) ?></td>
            <td><?= esc($i['assessor_name']) ?></td>
            <td><?= esc($i['academic_year']) ?></td>
            <td>
              <?php $bc=['completed'=>'badge-success','ongoing'=>'badge-info','withdrawn'=>'badge-danger'][$i['status']]??'badge-neutral'; ?>
              <span class="badge <?= $bc ?>"><?= ucfirst($i['status']) ?></span>
            </td>
            <td><?= $i['total_score'] !== null ? '<strong>'.number_format($i['total_score'],2).'</strong>' : '<span style="color:var(--text-ter)">—</span>' ?></td>
            <td>
              <div style="display:flex;gap:6px;">
                <a href="results.php?internship_id=<?= $i['internship_id'] ?>" class="btn btn-secondary btn-sm">Results</a>
                <button class="btn btn-secondary btn-sm" onclick="editInternship(<?= htmlspecialchars(json_encode($i),ENT_QUOTES) ?>)">Edit</button>
                <button class="btn btn-danger btn-sm" onclick="confirmDelete('internships.php?delete=<?= $i['internship_id'] ?>','internship #<?= $i['internship_id'] ?>')">Delete</button>
              </div>
            </td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php
$modal_fields = function($prefix='') use ($students, $companies, $assessors) { ?>
  <div class="form-grid">
    <div class="form-group form-full">
      <label class="form-label">Student <span class="req">*</span></label>
      <select name="student_id" id="<?= $prefix ?>student" class="form-control" required>
        <option value="">Select student…</option>
        <?php foreach ($students as $s): ?>
          <option value="<?= $s['student_id'] ?>"><?= esc($s['student_number'].' – '.$s['full_name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">Company <span class="req">*</span></label>
      <select name="company_id" id="<?= $prefix ?>company" class="form-control" required>
        <option value="">Select company…</option>
        <?php foreach ($companies as $c): ?>
          <option value="<?= $c['company_id'] ?>"><?= esc($c['company_name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">Assessor <span class="req">*</span></label>
      <select name="assessor_id" id="<?= $prefix ?>assessor" class="form-control" required>
        <option value="">Select assessor…</option>
        <?php foreach ($assessors as $a): ?>
          <option value="<?= $a['user_id'] ?>"><?= esc($a['full_name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">Academic Year <span class="req">*</span></label>
      <input type="text" name="academic_year" id="<?= $prefix ?>year" class="form-control" placeholder="e.g. 2024/2025" required>
    </div>
    <div class="form-group">
      <label class="form-label">Start Date</label>
      <input type="date" name="start_date" id="<?= $prefix ?>start" class="form-control">
    </div>
    <div class="form-group">
      <label class="form-label">End Date</label>
      <input type="date" name="end_date" id="<?= $prefix ?>end" class="form-control">
    </div>
    <div class="form-group">
      <label class="form-label">Status</label>
      <select name="status" id="<?= $prefix ?>status" class="form-control">
        <option value="ongoing">Ongoing</option>
        <option value="completed">Completed</option>
        <option value="withdrawn">Withdrawn</option>
      </select>
    </div>
  </div>
<?php }; ?>

<!-- Add Modal -->
<div class="modal-overlay" id="modal-add">
  <div class="modal" style="max-width:640px">
    <div class="modal-header">
      <span class="modal-title">Add Internship</span>
      <button class="modal-close" onclick="closeModal('modal-add')">×</button>
    </div>
    <form method="post" data-validate>
      <input type="hidden" name="action" value="add">
      <div class="modal-body"><?php $modal_fields('add-'); ?></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modal-add')">Cancel</button>
        <button type="submit" class="btn btn-primary">Add Record</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="modal-edit">
  <div class="modal" style="max-width:640px">
    <div class="modal-header">
      <span class="modal-title">Edit Internship</span>
      <button class="modal-close" onclick="closeModal('modal-edit')">×</button>
    </div>
    <form method="post" data-validate>
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="internship_id" id="edit-iid">
      <div class="modal-body"><?php $modal_fields('edit-'); ?></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modal-edit')">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script>
function editInternship(i) {
  document.getElementById('edit-iid').value      = i.internship_id;
  document.getElementById('edit-student').value  = i.student_id;
  document.getElementById('edit-company').value  = i.company_id;
  document.getElementById('edit-assessor').value = i.assessor_id;
  document.getElementById('edit-year').value     = i.academic_year;
  document.getElementById('edit-start').value    = i.start_date ?? '';
  document.getElementById('edit-end').value      = i.end_date   ?? '';
  document.getElementById('edit-status').value   = i.status;
  openModal('modal-edit');
}
</script>
<?php require_once '../includes/footer.php'; ?>
