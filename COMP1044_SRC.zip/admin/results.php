<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_admin();

$db = get_db();

$search        = trim($_GET['q']      ?? '');
$filter_status = trim($_GET['status'] ?? '');

// Fetch a single internship detail if requested
$detail = null;
if (isset($_GET['internship_id'])) {
    $iid  = (int)$_GET['internship_id'];
    $stmt = $db->prepare("
        SELECT i.*, s.full_name AS student_name, s.student_number,
               p.programme_name,
               c.company_name, c.industry, c.address,
               u.full_name AS assessor_name, u.email AS assessor_email,
               a.overall_comment, a.submitted_at, a.assessment_id
        FROM internships i
        JOIN students  s ON s.student_id  = i.student_id
        JOIN programmes p ON p.programme_id = s.programme_id
        JOIN companies c ON c.company_id  = i.company_id
        JOIN users     u ON u.user_id     = i.assessor_id
        LEFT JOIN assessments a ON a.internship_id = i.internship_id
        WHERE i.internship_id = ?
    ");
    $stmt->bind_param('i', $iid);
    $stmt->execute();
    $detail = $stmt->get_result()->fetch_assoc();

    if ($detail && $detail['assessment_id']) {
        $scores_res = $db->prepare("
            SELECT ac.criteria_name, ac.weightage, s.score, s.comment,
                   ROUND(s.score * ac.weightage / 100, 2) AS weighted
            FROM assessment_scores s
            JOIN assessment_criteria ac ON ac.criteria_id = s.criteria_id
            WHERE s.assessment_id = ?
            ORDER BY ac.criteria_id
        ");
        $scores_res->bind_param('i', $detail['assessment_id']);
        $scores_res->execute();
        $detail['scores'] = $scores_res->get_result()->fetch_all(MYSQLI_ASSOC);
        $detail['total']  = array_sum(array_column($detail['scores'], 'weighted'));
    }
}

// List all results
$sql = "
    SELECT i.internship_id, s.full_name AS student_name, s.student_number,
           c.company_name, u.full_name AS assessor_name, i.status, i.academic_year,
           vat.total_score, vat.submitted_at
    FROM internships i
    JOIN students  s ON s.student_id  = i.student_id
    JOIN companies c ON c.company_id  = i.company_id
    JOIN users     u ON u.user_id     = i.assessor_id
    LEFT JOIN v_assessment_totals vat ON vat.internship_id = i.internship_id
    WHERE 1=1
";
if ($search) {
    $like = '%'.$db->real_escape_string($search).'%';
    $sql .= " AND (s.full_name LIKE '$like' OR s.student_number LIKE '$like')";
}
if ($filter_status) {
    $fs = $db->real_escape_string($filter_status);
    $sql .= " AND i.status = '$fs'";
}
$sql .= " ORDER BY i.internship_id DESC";
$results = $db->query($sql)->fetch_all(MYSQLI_ASSOC);

function grade_label(float $score): array {
    if ($score >= 80) return ['A', 'grade-a'];
    if ($score >= 70) return ['B', 'grade-b'];
    if ($score >= 60) return ['C', 'grade-c'];
    if ($score >= 50) return ['D', 'grade-d'];
    return ['F', 'grade-f'];
}

$page_title = $detail ? 'Result Detail' : 'All Results';
$active_nav = 'results';
$base = '../';
require_once '../includes/header.php';
?>

<?php if ($detail): ?>
<!-- ---- DETAIL VIEW ---- -->
<div style="margin-bottom:16px;">
  <a href="results.php" class="btn btn-secondary btn-sm">← Back to All Results</a>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;" class="detail-top-grid">

  <div class="card">
    <div class="card-header"><span class="card-title">Student Information</span></div>
    <div class="card-body">
      <div class="detail-grid">
        <div class="detail-item"><div class="detail-label">Student No.</div><div class="detail-value"><?= esc($detail['student_number']) ?></div></div>
        <div class="detail-item"><div class="detail-label">Full Name</div><div class="detail-value"><?= esc($detail['student_name']) ?></div></div>
        <div class="detail-item"><div class="detail-label">Programme</div><div class="detail-value"><?= esc($detail['programme_name']) ?></div></div>
        <div class="detail-item"><div class="detail-label">Status</div><div class="detail-value">
          <?php $bc=['completed'=>'badge-success','ongoing'=>'badge-info','withdrawn'=>'badge-danger'][$detail['status']]??'badge-neutral'; ?>
          <span class="badge <?= $bc ?>"><?= ucfirst($detail['status']) ?></span>
        </div></div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><span class="card-title">Internship Details</span></div>
    <div class="card-body">
      <div class="detail-grid">
        <div class="detail-item"><div class="detail-label">Company</div><div class="detail-value"><?= esc($detail['company_name']) ?></div></div>
        <div class="detail-item"><div class="detail-label">Industry</div><div class="detail-value"><?= esc($detail['industry'] ?? '—') ?></div></div>
        <div class="detail-item"><div class="detail-label">Assessor</div><div class="detail-value"><?= esc($detail['assessor_name']) ?></div></div>
        <div class="detail-item"><div class="detail-label">Academic Year</div><div class="detail-value"><?= esc($detail['academic_year']) ?></div></div>
        <?php if ($detail['start_date']): ?>
        <div class="detail-item"><div class="detail-label">Period</div><div class="detail-value"><?= $detail['start_date'].' → '.$detail['end_date'] ?></div></div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php if (!empty($detail['scores'])): ?>
<div class="card" style="margin-bottom:20px;">
  <div class="card-header">
    <span class="card-title">Assessment Breakdown</span>
    <?php if ($detail['submitted_at']): ?>
      <span style="font-size:.78rem;color:var(--text-ter)">Submitted: <?= date('d M Y', strtotime($detail['submitted_at'])) ?></span>
    <?php endif; ?>
  </div>
  <div class="card-body no-pad">
    <div class="table-wrapper">
      <table>
        <thead>
          <tr><th>Assessment Criteria</th><th>Weight</th><th>Score /100</th><th>Weighted</th><th>Comment</th></tr>
        </thead>
        <tbody>
          <?php foreach ($detail['scores'] as $sc): ?>
          <tr>
            <td><?= esc($sc['criteria_name']) ?></td>
            <td><?= $sc['weightage'] ?>%</td>
            <td>
              <div style="display:flex;align-items:center;gap:8px;">
                <span><?= $sc['score'] ?></span>
                <div class="score-bar-wrap" style="width:60px">
                  <div class="score-bar <?= $sc['score']>=70?'score-bar-high':($sc['score']>=50?'score-bar-mid':'score-bar-low') ?>"
                       style="width:<?= $sc['score'] ?>%"></div>
                </div>
              </div>
            </td>
            <td><strong><?= $sc['weighted'] ?></strong></td>
            <td style="font-size:.82rem;color:var(--text-sec)"><?= esc($sc['comment'] ?? '—') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="total-score-box">
  <div>
    <div class="total-score-label">FINAL INTERNSHIP SCORE</div>
    <?php if ($detail['overall_comment']): ?>
      <div style="font-size:.85rem;margin-top:6px;color:var(--text-sec)"><?= esc($detail['overall_comment']) ?></div>
    <?php endif; ?>
  </div>
  <div style="text-align:right;">
    <div class="total-score-value"><?= number_format($detail['total'],2) ?></div>
    <?php [$g,$gc] = grade_label($detail['total']); ?>
    <span class="badge <?= $gc ?>" style="margin-top:6px;font-size:.85rem;">Grade <?= $g ?></span>
  </div>
</div>

<?php else: ?>
<div class="card">
  <div class="card-body">
    <div class="empty-state">
      <div class="empty-state-icon">◌</div>
      <div class="empty-state-text">No assessment submitted yet for this internship.</div>
    </div>
  </div>
</div>
<?php endif; ?>

<?php else: ?>
<!-- ---- LIST VIEW ---- -->
<div class="section-header">
  <h2 class="section-title">All Results</h2>
</div>

<div class="card" style="margin-bottom:20px;">
  <div class="card-body" style="padding:14px 18px;">
    <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;">
      <input type="text" name="q" class="search-input" placeholder="Search by name or student number…" value="<?= esc($search) ?>" style="flex:1;min-width:200px;">
      <select name="status" class="form-control" style="width:160px;">
        <option value="">All Status</option>
        <option value="ongoing"   <?= $filter_status==='ongoing'?'selected':''?>>Ongoing</option>
        <option value="completed" <?= $filter_status==='completed'?'selected':''?>>Completed</option>
        <option value="withdrawn" <?= $filter_status==='withdrawn'?'selected':''?>>Withdrawn</option>
      </select>
      <button type="submit" class="btn btn-primary">Filter</button>
      <?php if ($search||$filter_status): ?><a href="results.php" class="btn btn-secondary">Clear</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-body no-pad">
    <div class="table-wrapper">
      <table>
        <thead>
          <tr><th>#</th><th>Student</th><th>Company</th><th>Assessor</th><th>Year</th><th>Status</th><th>Score</th><th>Grade</th><th>Action</th></tr>
        </thead>
        <tbody>
          <?php if (empty($results)): ?>
          <tr><td colspan="9"><div class="empty-state"><div class="empty-state-icon">◌</div><div class="empty-state-text">No results found.</div></div></td></tr>
          <?php else: foreach ($results as $r): ?>
          <tr>
            <td><?= $r['internship_id'] ?></td>
            <td><div style="font-weight:500"><?= esc($r['student_name']) ?></div><div style="font-size:.78rem;color:var(--text-ter)"><?= esc($r['student_number']) ?></div></td>
            <td><?= esc($r['company_name']) ?></td>
            <td><?= esc($r['assessor_name']) ?></td>
            <td><?= esc($r['academic_year']) ?></td>
            <td>
              <?php $bc=['completed'=>'badge-success','ongoing'=>'badge-info','withdrawn'=>'badge-danger'][$r['status']]??'badge-neutral'; ?>
              <span class="badge <?= $bc ?>"><?= ucfirst($r['status']) ?></span>
            </td>
            <td><?= $r['total_score'] !== null ? '<strong>'.number_format($r['total_score'],2).'</strong>' : '<span style="color:var(--text-ter)">—</span>' ?></td>
            <td>
              <?php if ($r['total_score'] !== null):
                [$g,$gc] = grade_label((float)$r['total_score']); ?>
                <span class="badge <?= $gc ?>"><?= $g ?></span>
              <?php else: ?><span style="color:var(--text-ter)">—</span><?php endif; ?>
            </td>
            <td><a href="results.php?internship_id=<?= $r['internship_id'] ?>" class="btn btn-secondary btn-sm">View</a></td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php endif; ?>

<style>
@media(max-width:700px){.detail-top-grid{grid-template-columns:1fr!important;}}
</style>

<?php require_once '../includes/footer.php'; ?>
