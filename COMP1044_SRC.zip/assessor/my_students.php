<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_assessor();

$db  = get_db();
$uid = (int)$_SESSION['user_id'];

$search = trim($_GET['q'] ?? '');
$sql = "
    SELECT i.internship_id, s.student_number, s.full_name AS student_name,
           p.programme_name,
           c.company_name, i.status, i.academic_year,
           vat.total_score, a.submitted_at
    FROM internships i
    JOIN students  s ON s.student_id    = i.student_id
    JOIN programmes p ON p.programme_id = s.programme_id
    JOIN companies c ON c.company_id    = i.company_id
    LEFT JOIN v_assessment_totals vat ON vat.internship_id = i.internship_id
    LEFT JOIN assessments a ON a.internship_id = i.internship_id
    WHERE i.assessor_id = $uid
";
if ($search) {
    $like = '%'.$db->real_escape_string($search).'%';
    $sql .= " AND (s.full_name LIKE '$like' OR s.student_number LIKE '$like')";
}
$sql .= " ORDER BY s.full_name";
$students = $db->query($sql)->fetch_all(MYSQLI_ASSOC);

$page_title = 'My Students';
$active_nav = 'students';
$base = '../';
require_once '../includes/header.php';
?>

<div class="section-header">
  <h2 class="section-title">My Assigned Students</h2>
</div>

<div class="card" style="margin-bottom:20px;">
  <div class="card-body" style="padding:14px 18px;">
    <form method="get" style="display:flex;gap:10px;">
      <input type="text" name="q" class="search-input" placeholder="Search by name or student number…" value="<?= esc($search) ?>">
      <button type="submit" class="btn btn-primary">Search</button>
      <?php if ($search): ?><a href="my_students.php" class="btn btn-secondary">Clear</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-body no-pad">
    <div class="table-wrapper">
      <table>
        <thead>
          <tr><th>Student No.</th><th>Name</th><th>Programme</th><th>Company</th><th>Year</th><th>Status</th><th>Score</th><th>Action</th></tr>
        </thead>
        <tbody>
          <?php if (empty($students)): ?>
          <tr><td colspan="8"><div class="empty-state"><div class="empty-state-icon">◌</div><div class="empty-state-text">No students assigned.</div></div></td></tr>
          <?php else: foreach ($students as $r): ?>
          <tr>
            <td><strong><?= esc($r['student_number']) ?></strong></td>
            <td><?= esc($r['student_name']) ?></td>
            <td><?= esc($r['programme_name']) ?></td>
            <td><?= esc($r['company_name']) ?></td>
            <td><?= esc($r['academic_year']) ?></td>
            <td>
              <?php $bc=['completed'=>'badge-success','ongoing'=>'badge-info','withdrawn'=>'badge-danger'][$r['status']]??'badge-neutral'; ?>
              <span class="badge <?= $bc ?>"><?= ucfirst($r['status']) ?></span>
            </td>
            <td><?= $r['total_score'] !== null ? '<strong>'.number_format($r['total_score'],2).'</strong>' : '<span style="color:var(--text-ter)">—</span>' ?></td>
            <td>
              <div style="display:flex;gap:6px;">
                <?php if ($r['submitted_at']): ?>
                  <a href="results.php?internship_id=<?= $r['internship_id'] ?>" class="btn btn-secondary btn-sm">View Result</a>
                  <a href="assess.php?internship_id=<?= $r['internship_id'] ?>&edit=1" class="btn btn-secondary btn-sm">Edit</a>
                <?php else: ?>
                  <a href="assess.php?internship_id=<?= $r['internship_id'] ?>" class="btn btn-primary btn-sm">Assess</a>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
