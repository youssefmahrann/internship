<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_assessor();

$db  = get_db();
$uid = (int)$_SESSION['user_id'];
$iid = (int)($_GET['internship_id'] ?? $_POST['internship_id'] ?? 0);

if (!$iid) { header('Location: my_students.php'); exit(); }

// Load internship — ensure belongs to this assessor (unless admin)
$stmt = $db->prepare("
    SELECT i.*, s.full_name AS student_name, s.student_number,
           p.programme_name, c.company_name
    FROM internships i
    JOIN students  s ON s.student_id  = i.student_id
    JOIN programmes p ON p.programme_id = s.programme_id
    JOIN companies c ON c.company_id  = i.company_id
    WHERE i.internship_id = ?
    " . (is_admin() ? '' : " AND i.assessor_id = $uid")
);
$stmt->bind_param('i', $iid);
$stmt->execute();
$intern = $stmt->get_result()->fetch_assoc();
if (!$intern) { set_flash('danger','Internship not found or access denied.'); header('Location: my_students.php'); exit(); }

// Load criteria
$criteria = $db->query("SELECT * FROM assessment_criteria ORDER BY criteria_id")->fetch_all(MYSQLI_ASSOC);

// Load existing assessment if any
$existing_a = $db->prepare("SELECT * FROM assessments WHERE internship_id=?");
$existing_a->bind_param('i', $iid); $existing_a->execute();
$assessment = $existing_a->get_result()->fetch_assoc();

$existing_scores = [];
if ($assessment) {
    $es = $db->prepare("SELECT criteria_id, score, comment FROM assessment_scores WHERE assessment_id=?");
    $es->bind_param('i', $assessment['assessment_id']); $es->execute();
    foreach ($es->get_result()->fetch_all(MYSQLI_ASSOC) as $row) {
        $existing_scores[$row['criteria_id']] = $row;
    }
}

// ---- Handle POST ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comment = trim($_POST['overall_comment'] ?? '');
    $scores  = $_POST['score']   ?? [];
    $comments= $_POST['comment'] ?? [];

    $errors = [];
    foreach ($criteria as $c) {
        $cid = $c['criteria_id'];
        $val = $scores[$cid] ?? '';
        if ($val === '' || !is_numeric($val)) {
            $errors[] = 'Please enter a score for: ' . $c['criteria_name'];
        } elseif ($val < 0 || $val > 100) {
            $errors[] = 'Score must be 0-100 for: ' . $c['criteria_name'];
        }
    }

    if (empty($errors)) {
        $db->begin_transaction();
        try {
            if ($assessment) {
                // Update
                $upd = $db->prepare("UPDATE assessments SET overall_comment=?, submitted_at=NOW() WHERE assessment_id=?");
                $upd->bind_param('si', $comment, $assessment['assessment_id']);
                $upd->execute();
                $aid = $assessment['assessment_id'];
            } else {
                // Insert
                $ins = $db->prepare("INSERT INTO assessments (internship_id,assessor_id,overall_comment,submitted_at) VALUES (?,?,?,NOW())");
                $ins->bind_param('iis', $iid, $uid, $comment);
                $ins->execute();
                $aid = $db->insert_id;
            }

            foreach ($criteria as $c) {
                $cid     = $c['criteria_id'];
                $sval    = (float)$scores[$cid];
                $scmt    = trim($comments[$cid] ?? '');
                $upsert  = $db->prepare("
                    INSERT INTO assessment_scores (assessment_id, criteria_id, score, comment)
                    VALUES (?,?,?,?)
                    ON DUPLICATE KEY UPDATE score=VALUES(score), comment=VALUES(comment)
                ");
                $upsert->bind_param('iids', $aid, $cid, $sval, $scmt);
                $upsert->execute();
            }
            $db->commit();
            set_flash('success', 'Assessment submitted successfully.');
            header('Location: results.php?internship_id=' . $iid);
            exit();
        } catch (Exception $e) {
            $db->rollback();
            set_flash('danger', 'Error saving assessment: ' . $e->getMessage());
        }
    } else {
        set_flash('danger', implode('<br>', $errors));
    }
}

$page_title = 'Assess: ' . $intern['student_name'];
$active_nav = 'students';
$base = '../';
require_once '../includes/header.php';
?>

<div style="margin-bottom:16px;">
  <a href="my_students.php" class="btn btn-secondary btn-sm">← Back</a>
</div>

<!-- Info card -->
<div class="card" style="margin-bottom:20px;">
  <div class="card-body">
    <div class="detail-grid">
      <div class="detail-item"><div class="detail-label">Student No.</div><div class="detail-value"><?= esc($intern['student_number']) ?></div></div>
      <div class="detail-item"><div class="detail-label">Name</div><div class="detail-value"><?= esc($intern['student_name']) ?></div></div>
      <div class="detail-item"><div class="detail-label">Programme</div><div class="detail-value"><?= esc($intern['programme_name']) ?></div></div>
      <div class="detail-item"><div class="detail-label">Company</div><div class="detail-value"><?= esc($intern['company_name']) ?></div></div>
    </div>
  </div>
</div>

<!-- Assessment Form -->
<form method="post" data-validate>
  <input type="hidden" name="internship_id" value="<?= $iid ?>">

  <div class="card" style="margin-bottom:20px;">
    <div class="card-header">
      <span class="card-title">Assessment Criteria</span>
      <div style="display:flex;align-items:center;gap:12px;">
        <span style="font-size:.82rem;color:var(--text-sec)">Total:</span>
        <strong id="total-score-display" style="font-size:1.2rem;color:var(--accent)">--</strong>
        <span id="grade-display" class="badge" style="font-size:.85rem;"></span>
      </div>
    </div>
    <div class="score-grid">
      <?php foreach ($criteria as $c):
        $cid = $c['criteria_id'];
        $prev_score   = $existing_scores[$cid]['score']   ?? '';
        $prev_comment = $existing_scores[$cid]['comment'] ?? '';
      ?>
      <div class="score-row" data-weight="<?= $c['weightage'] ?>">
        <div>
          <div class="score-criteria-name"><?= esc($c['criteria_name']) ?></div>
          <div class="score-weight">Weight: <?= $c['weightage'] ?>%</div>
          <div class="score-bar-wrap" style="margin-top:6px;width:120px;">
            <div class="score-bar" style="width:<?= $prev_score !== '' ? $prev_score : 0 ?>%"></div>
          </div>
        </div>
        <div class="score-input-wrap">
          <label class="form-label" style="text-align:center;font-size:.75rem;">Score (0–100)</label>
          <input type="number" name="score[<?= $cid ?>]" class="form-control score-input"
                 min="0" max="100" step="0.5" required
                 value="<?= $prev_score !== '' ? esc((string)$prev_score) : '' ?>"
                 placeholder="0–100">
        </div>
        <div>
          <label class="form-label" style="font-size:.75rem;">Comments</label>
          <textarea name="comment[<?= $cid ?>]" class="form-control" rows="2"
                    placeholder="Optional comment…"><?= esc($prev_comment) ?></textarea>
          <div class="score-result" style="font-size:.78rem;color:var(--text-sec);margin-top:4px;">
            Weighted: <span class="score-result-val">—</span>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="card" style="margin-bottom:20px;">
    <div class="card-header"><span class="card-title">Overall Comment</span></div>
    <div class="card-body">
      <div class="form-group">
        <label class="form-label">General remarks / feedback for this student</label>
        <textarea name="overall_comment" class="form-control" rows="4"
                  placeholder="Provide an overall summary of the student's internship performance…"><?= esc($assessment['overall_comment'] ?? '') ?></textarea>
      </div>
    </div>
  </div>

  <div class="total-score-box" style="margin-bottom:20px;">
    <div>
      <div class="total-score-label">CALCULATED FINAL SCORE</div>
      <div style="font-size:.82rem;color:var(--accent);margin-top:4px;">Based on fixed weightages — auto-calculated</div>
    </div>
    <div style="text-align:right;">
      <div class="total-score-value" id="total-score-display">--</div>
      <span id="grade-display" class="badge" style="margin-top:6px;font-size:.9rem;"></span>
    </div>
  </div>

  <div class="form-actions">
    <a href="my_students.php" class="btn btn-secondary">Cancel</a>
    <button type="submit" class="btn btn-primary">
      <?= $assessment ? 'Update Assessment' : 'Submit Assessment' ?>
    </button>
  </div>
</form>

<?php require_once '../includes/footer.php'; ?>
