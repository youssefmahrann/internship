<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_assessor();

$db  = get_db();
$uid = (int)$_SESSION['user_id'];

// Stats
$total_students = $db->query("SELECT COUNT(*) c FROM internships WHERE assessor_id=$uid")->fetch_assoc()['c'];
$assessed       = $db->query("SELECT COUNT(*) c FROM assessments a JOIN internships i ON i.internship_id=a.internship_id WHERE i.assessor_id=$uid AND a.submitted_at IS NOT NULL")->fetch_assoc()['c'];
$pending        = $total_students - $assessed;

// Recent my internships
$my_list = $db->query("
    SELECT i.internship_id, s.student_number, s.full_name AS student_name,
           c.company_name, i.status, vat.total_score, a.submitted_at
    FROM internships i
    JOIN students  s ON s.student_id  = i.student_id
    JOIN companies c ON c.company_id  = i.company_id
    LEFT JOIN v_assessment_totals vat ON vat.internship_id = i.internship_id
    LEFT JOIN assessments a ON a.internship_id = i.internship_id
    WHERE i.assessor_id = $uid
    ORDER BY i.created_at DESC LIMIT 8
")->fetch_all(MYSQLI_ASSOC);

$page_title = 'Dashboard';
$active_nav = 'dashboard';
$base = '../';
require_once '../includes/header.php';
?>

<div class="stats-grid">
  <div class="stat-card stat-accent">
    <div class="stat-label">Assigned Students</div>
    <div class="stat-value"><?= $total_students ?></div>
    <div class="stat-sub">Total internships assigned</div>
  </div>
  <div class="stat-card stat-success">
    <div class="stat-label">Assessed</div>
    <div class="stat-value"><?= $assessed ?></div>
    <div class="stat-sub">Submissions completed</div>
  </div>
  <div class="stat-card stat-warning">
    <div class="stat-label">Pending</div>
    <div class="stat-value"><?= $pending ?></div>
    <div class="stat-sub">Awaiting assessment</div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <span class="card-title">My Students</span>
    <a href="my_students.php" class="btn btn-secondary btn-sm">View All</a>
  </div>
  <div class="card-body no-pad">
    <div class="table-wrapper">
      <table>
        <thead>
          <tr><th>Student</th><th>Company</th><th>Status</th><th>Score</th><th>Action</th></tr>
        </thead>
        <tbody>
          <?php if (empty($my_list)): ?>
          <tr><td colspan="5"><div class="empty-state"><div class="empty-state-icon">◌</div><div class="empty-state-text">No students assigned yet.</div></div></td></tr>
          <?php else: foreach ($my_list as $r): ?>
          <tr>
            <td>
              <div style="font-weight:500"><?= esc($r['student_name']) ?></div>
              <div style="font-size:.78rem;color:var(--text-ter)"><?= esc($r['student_number']) ?></div>
            </td>
            <td><?= esc($r['company_name']) ?></td>
            <td>
              <?php $bc=['completed'=>'badge-success','ongoing'=>'badge-info','withdrawn'=>'badge-danger'][$r['status']]??'badge-neutral'; ?>
              <span class="badge <?= $bc ?>"><?= ucfirst($r['status']) ?></span>
            </td>
            <td><?= $r['total_score'] !== null ? '<strong>'.number_format($r['total_score'],2).'</strong>' : '<span style="color:var(--text-ter)">Pending</span>' ?></td>
            <td>
              <?php if ($r['submitted_at']): ?>
                <a href="results.php?internship_id=<?= $r['internship_id'] ?>" class="btn btn-secondary btn-sm">View</a>
              <?php else: ?>
                <a href="assess.php?internship_id=<?= $r['internship_id'] ?>" class="btn btn-primary btn-sm">Assess</a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
