// ============================================================
// InternTrack – app.js
// ============================================================

// ----- Auto-dismiss alerts after 5s -----
document.querySelectorAll('.alert').forEach(el => {
  setTimeout(() => el.remove(), 5000);
});

// ----- Modal helpers -----
function openModal(id) {
  document.getElementById(id)?.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  document.getElementById(id)?.classList.remove('open');
  document.body.style.overflow = '';
}

// Close modal on overlay click
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) {
      overlay.classList.remove('open');
      document.body.style.overflow = '';
    }
  });
});

// ----- Confirm delete -----
function confirmDelete(url, name) {
  if (confirm(`Are you sure you want to delete "${name}"? This action cannot be undone.`)) {
    window.location.href = url;
  }
}

// ----- Score input: live weighted calculation -----
function calcScores() {
  const rows  = document.querySelectorAll('.score-row[data-weight]');
  let total   = 0;
  let allFilled = true;
  rows.forEach(row => {
    const input   = row.querySelector('.score-input');
    const weight  = parseFloat(row.dataset.weight);
    const result  = row.querySelector('.score-result-val');
    const bar     = row.querySelector('.score-bar');

    const val = parseFloat(input?.value ?? '');
    if (isNaN(val) || input?.value === '') { allFilled = false; return; }

    const weighted = (val * weight / 100);
    total += weighted;

    if (result)  result.textContent = weighted.toFixed(2) + ' marks';
    if (bar) {
      const pct = Math.min(val, 100);
      bar.style.width = pct + '%';
      bar.className = 'score-bar ' + (pct >= 70 ? 'score-bar-high' : pct >= 50 ? 'score-bar-mid' : 'score-bar-low');
    }
  });

  const totalEl = document.getElementById('total-score-display');
  if (totalEl) {
    totalEl.textContent = allFilled ? total.toFixed(2) : '--';
  }
  const gradeEl = document.getElementById('grade-display');
  if (gradeEl && allFilled) {
    const g = getGrade(total);
    gradeEl.textContent = g.grade;
    gradeEl.className   = 'badge ' + g.cls;
  }
}

function getGrade(score) {
  if (score >= 80) return { grade: 'A',  cls: 'grade-a' };
  if (score >= 70) return { grade: 'B',  cls: 'grade-b' };
  if (score >= 60) return { grade: 'C',  cls: 'grade-c' };
  if (score >= 50) return { grade: 'D',  cls: 'grade-d' };
  return               { grade: 'F',  cls: 'grade-f' };
}

// Attach listeners
document.querySelectorAll('.score-input').forEach(input => {
  input.addEventListener('input', () => {
    // Range validation
    let v = parseFloat(input.value);
    if (!isNaN(v)) {
      if (v > 100) input.value = 100;
      if (v < 0)   input.value = 0;
    }
    calcScores();
  });
});

// Initial calculation on page load
calcScores();

// ----- Table search / filter -----
const searchInput = document.getElementById('table-search');
if (searchInput) {
  searchInput.addEventListener('input', function() {
    const q   = this.value.toLowerCase();
    const trs = document.querySelectorAll('tbody tr[data-search]');
    trs.forEach(tr => {
      const text = tr.dataset.search.toLowerCase();
      tr.style.display = text.includes(q) ? '' : 'none';
    });
    const empty = document.getElementById('search-empty');
    if (empty) {
      const visible = [...trs].filter(tr => tr.style.display !== 'none');
      empty.style.display = visible.length === 0 ? '' : 'none';
    }
  });
}

// ----- Form validation -----
document.querySelectorAll('form[data-validate]').forEach(form => {
  form.addEventListener('submit', function(e) {
    let valid = true;
    form.querySelectorAll('[required]').forEach(field => {
      const errEl = field.parentElement.querySelector('.form-error');
      if (!field.value.trim()) {
        field.classList.add('is-invalid');
        if (errEl) errEl.textContent = 'This field is required.';
        valid = false;
      } else {
        field.classList.remove('is-invalid');
        if (errEl) errEl.textContent = '';
      }
    });
    if (!valid) e.preventDefault();
  });
});

// Password strength indicator on register
const pwdInput = document.getElementById('password-input');
if (pwdInput) {
  pwdInput.addEventListener('input', function() {
    const val = this.value;
    const strong = /^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/.test(val);
    const medium = val.length >= 6;
    const bar = document.getElementById('pwd-strength-bar');
    const lbl = document.getElementById('pwd-strength-lbl');
    if (bar && lbl) {
      if (strong)      { bar.style.width='100%'; bar.className='score-bar score-bar-high'; lbl.textContent='Strong'; }
      else if (medium) { bar.style.width='55%';  bar.className='score-bar score-bar-mid';  lbl.textContent='Medium'; }
      else             { bar.style.width='20%';  bar.className='score-bar score-bar-low';  lbl.textContent='Weak'; }
    }
  });
}
