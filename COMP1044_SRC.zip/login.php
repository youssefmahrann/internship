<?php
require_once 'includes/config.php';
require_once 'includes/db.php';

// Redirect if already logged in
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['role'] === 'admin' ? 'admin/dashboard.php' : 'assessor/dashboard.php'));
    exit();
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!$email || !$password) {
        $error = 'Please enter both email and password.';
    } else {
        $db   = get_db();
        $stmt = $db->prepare(
            "SELECT user_id, full_name, email, password_hash, role, is_active
             FROM users WHERE email = ? LIMIT 1"
        );
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$row) {
            $error = 'Invalid email or password.';
        } elseif (!$row['is_active']) {
            $error = 'Your account has been deactivated. Contact admin.';
        } elseif (!password_verify($password, $row['password_hash'])) {
            $error = 'Invalid email or password.';
        } else {
            // Login success
            session_regenerate_id(true);
            $_SESSION['user_id']       = $row['user_id'];
            $_SESSION['full_name']     = $row['full_name'];
            $_SESSION['email']         = $row['email'];
            $_SESSION['role']          = $row['role'];
            $_SESSION['last_activity'] = time();

            header('Location: ' . ($row['role'] === 'admin' ? 'admin/dashboard.php' : 'assessor/dashboard.php'));
            exit();
        }
    }
}

$timeout = isset($_GET['timeout']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In – InternTrack</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=DM+Serif+Display&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="login-page">

  <!-- Left brand panel -->
  <div class="login-brand">
    <div class="login-brand-content">
      <div class="login-brand-logo">⬡</div>
      <h1>InternTrack</h1>
      <p>Internship Result Management System – streamlined, transparent, and accurate.</p>
    </div>
  </div>

  <!-- Right form panel -->
  <div class="login-form-wrap">
    <div class="login-box">
      <h2>Welcome back</h2>
      <p class="sub">Sign in to your account to continue.</p>

      <?php if ($timeout): ?>
        <div class="alert alert-warning" style="margin-bottom:16px;">
          Your session has expired. Please sign in again.
          <button class="alert-close" onclick="this.parentElement.remove()">×</button>
        </div>
      <?php endif; ?>

      <?php if ($error): ?>
        <div class="alert alert-danger" style="margin-bottom:16px;">
          <?= esc($error) ?>
          <button class="alert-close" onclick="this.parentElement.remove()">×</button>
        </div>
      <?php endif; ?>

      <form method="post" action="login.php" data-validate>
        <div class="form-group">
          <label class="form-label" for="email">Email address <span class="req">*</span></label>
          <input type="email" id="email" name="email" class="form-control"
                 placeholder="you@university.edu"
                 value="<?= esc($email) ?>" required autocomplete="email">
          <span class="form-error"></span>
        </div>
        <div class="form-group" style="margin-top:14px;">
          <label class="form-label" for="password">Password <span class="req">*</span></label>
          <input type="password" id="password" name="password" class="form-control"
                 placeholder="Enter your password" required autocomplete="current-password">
          <span class="form-error"></span>
        </div>
        <button type="submit" class="btn btn-primary login-btn" style="margin-top:20px;">
          Sign In
        </button>
      </form>

      <p style="margin-top:24px; font-size:.78rem; color:var(--text-ter); text-align:center;">
        Demo credentials: admin@university.edu / Pass@1234<br>
        Assessor: youssefmahran@university.edu / Pass@1234
      </p>
    </div>
  </div>
</div>
<script src="js/app.js"></script>
</body>
</html>
