<?php
// includes/header.php
// Params expected: $page_title, $active_nav (optional)
$page_title = $page_title ?? 'InternTrack';
$user_name  = $_SESSION['full_name'] ?? 'User';
$user_role  = $_SESSION['role']      ?? '';
$base        = (isset($is_admin_page) && $is_admin_page) ? '../' : '../';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= esc($page_title) ?> – InternTrack</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=DM+Serif+Display&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= $base ?>css/style.css">
</head>
<body>

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <span class="logo-icon">⬡</span>
    <span class="logo-text">InternTrack</span>
  </div>

  <nav class="sidebar-nav">
    <?php if ($user_role === 'admin'): ?>
      <a href="<?= $base ?>admin/dashboard.php"   class="nav-item <?= ($active_nav??'')==='dashboard'?'active':'' ?>">
        <span class="nav-icon">◈</span> Dashboard
      </a>
      <div class="nav-section-label">MANAGE</div>
      <a href="<?= $base ?>admin/students.php"    class="nav-item <?= ($active_nav??'')==='students'?'active':'' ?>">
        <span class="nav-icon">◉</span> Students
      </a>
      <a href="<?= $base ?>admin/internships.php" class="nav-item <?= ($active_nav??'')==='internships'?'active':'' ?>">
        <span class="nav-icon">◎</span> Internships
      </a>
      <a href="<?= $base ?>admin/assessors.php"   class="nav-item <?= ($active_nav??'')==='assessors'?'active':'' ?>">
        <span class="nav-icon">◍</span> Assessors
      </a>
      <div class="nav-section-label">RESULTS</div>
      <a href="<?= $base ?>admin/results.php"     class="nav-item <?= ($active_nav??'')==='results'?'active':'' ?>">
        <span class="nav-icon">◐</span> All Results
      </a>
    <?php else: ?>
      <a href="<?= $base ?>assessor/dashboard.php"  class="nav-item <?= ($active_nav??'')==='dashboard'?'active':'' ?>">
        <span class="nav-icon">◈</span> Dashboard
      </a>
      <div class="nav-section-label">ASSESSMENT</div>
      <a href="<?= $base ?>assessor/my_students.php" class="nav-item <?= ($active_nav??'')==='students'?'active':'' ?>">
        <span class="nav-icon">◉</span> My Students
      </a>
      <a href="<?= $base ?>assessor/results.php"     class="nav-item <?= ($active_nav??'')==='results'?'active':'' ?>">
        <span class="nav-icon">◐</span> Results
      </a>
    <?php endif; ?>
  </nav>

  <div class="sidebar-footer">
    <div class="user-chip">
      <div class="user-avatar"><?= strtoupper(substr($user_name,0,1)) ?></div>
      <div class="user-info">
        <div class="user-name"><?= esc($user_name) ?></div>
        <div class="user-role"><?= ucfirst($user_role) ?></div>
      </div>
    </div>
    <a href="<?= $base ?>logout.php" class="btn-logout">Sign out</a>
  </div>
</aside>

<!-- Main wrapper -->
<div class="main-wrapper">
  <header class="topbar">
    <button class="hamburger" onclick="document.getElementById('sidebar').classList.toggle('open')" aria-label="Toggle menu">
      <span></span><span></span><span></span>
    </button>
    <h1 class="page-title"><?= esc($page_title) ?></h1>
    <div class="topbar-right">
      <span class="topbar-date"><?= date('d M Y') ?></span>
    </div>
  </header>

  <main class="content">
    <?php
    $flash = get_flash();
    if ($flash['msg']): ?>
    <div class="alert alert-<?= esc($flash['type']) ?>">
      <?= esc($flash['msg']) ?>
      <button class="alert-close" onclick="this.parentElement.remove()">×</button>
    </div>
    <?php endif; ?>
