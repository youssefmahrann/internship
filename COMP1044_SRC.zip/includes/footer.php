  </main><!-- /.content -->
</div><!-- /.main-wrapper -->

<script src="<?= $base ?>js/app.js"></script>
</body>
</html>
