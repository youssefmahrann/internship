<?php
// ============================================================
// Database Configuration
// ============================================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'comp1044_irms');

define('APP_NAME', 'InternTrack');
define('APP_VERSION', '1.0.0');

// Session timeout in seconds (30 minutes)
define('SESSION_TIMEOUT', 1800);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Session timeout check
if (isset($_SESSION['last_activity'])) {
    if (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT) {
        session_unset();
        session_destroy();
                $isNested = strpos($_SERVER['SCRIPT_NAME'] ?? '', '/admin/') !== false || strpos($_SERVER['SCRIPT_NAME'] ?? '', '/assessor/') !== false || strpos($_SERVER['SCRIPT_NAME'] ?? '', '/includes/') !== false;
        header('Location: ' . ($isNested ? '../login.php?timeout=1' : 'login.php?timeout=1'));
        exit();
    }
}
if (isset($_SESSION['user_id'])) {
    $_SESSION['last_activity'] = time();
}
