<?php
require_once __DIR__ . '/config.php';

function get_db(): mysqli {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            die(json_encode([
                'error' => 'Database connection failed: ' . $conn->connect_error
            ]));
        }
        $conn->set_charset('utf8mb4');
    }
    return $conn;
}

// Safe escape helper
function esc(string $val): string {
    return htmlspecialchars($val, ENT_QUOTES, 'UTF-8');
}

// Flash message helpers
function set_flash(string $type, string $msg): void {
    $_SESSION['flash_type'] = $type;
    $_SESSION['flash_msg']  = $msg;
}

function get_flash(): array {
    $data = [
        'type' => $_SESSION['flash_type'] ?? '',
        'msg'  => $_SESSION['flash_msg']  ?? '',
    ];
    unset($_SESSION['flash_type'], $_SESSION['flash_msg']);
    return $data;
}

// Auth guard
function require_login(): void {
    if (empty($_SESSION['user_id'])) {
        header('Location: ../login.php');
        exit();
    }
}

function require_admin(): void {
    require_login();
    if ($_SESSION['role'] !== 'admin') {
        header('Location: ../assessor/dashboard.php');
        exit();
    }
}

function require_assessor(): void {
    require_login();
    if ($_SESSION['role'] !== 'assessor' && $_SESSION['role'] !== 'admin') {
        header('Location: ../login.php');
        exit();
    }
}

function is_admin(): bool {
    return ($_SESSION['role'] ?? '') === 'admin';
}
